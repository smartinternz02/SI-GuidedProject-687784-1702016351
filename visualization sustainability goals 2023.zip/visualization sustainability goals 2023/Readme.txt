Author : P.Chandralekha
Assistant Professor, 
Anand Institute of Higher Technology, Chennai.

this is a project on Visualization Suatainability Developement Goals 2023.
which has dashboard, report, stories and problem description.

in this we are doing the analysis on Sustainability Developement Goal index_score  with 
sdg__index with sdg_goal 1_score (no Poverty)
sdg_goal 14_score with sdg_goal 4_score(life below water with quality of education)
sdg_goal 14_score with sdg_goal 15_score (life below water with life on land)
sdg_goal 10_score with sdg_goal 15_score (life below water with reduce inequalities)
sdg_goal 14_score with sdg_goal 9_score (life below water with Industry,Innovation and Infrastructure)
sdg_goal 17_score with sdg_goal 14_score (life below water with Partnership to acheive goals)